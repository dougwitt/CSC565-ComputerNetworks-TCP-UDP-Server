//
//  main.cpp
//  Assignment 1
//
//  Created by Douglas Witt on 3/25/24.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
